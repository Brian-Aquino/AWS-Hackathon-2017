//
//  Notifier-Bridging-Header.h
//  Notifier
//
//  Created by kang ki-hoon on 2017. 6. 11..
//  Copyright © 2017년 kang ki-hoon. All rights reserved.
//

#ifndef Notifier_Bridging_Header_h
#define Notifier_Bridging_Header_h
#import <AWSCore/AWSCore.h>
#import <AWSCognito/AWSCognito.h>

#endif /* Notifier_Bridging_Header_h */
